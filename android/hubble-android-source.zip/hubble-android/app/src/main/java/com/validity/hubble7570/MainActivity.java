package com.validity.hubble7570;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final String TAG = "Hubble7570";
    private static final String ARCHIVE_DIR = "/sdcard/hubble";
    private static final String EXPECTED_SBOOT_SHA256 = "505b9b9e8192b9fa4ee4bb2229e7934327444a47c408eaa6b300facb1c629841";
    private static final String ROOT_BINARY_DEST = "/data/local/tmp/hubble7570-usb";

    private static final Stage[] STAGES = new Stage[] {
            new Stage("fwbl1.dnw", 0x00000, 0x02000),
            new Stage("bl31.dnw",  0x02000, 0x1E000),
            new Stage("bl2.dnw",   0x20000, 0x0D000),
            new Stage("u-boot.dnw",0x2D000, 0xD1000)
    };

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final List<File> archives = new ArrayList<>();

    private TextView rootStatus;
    private TextView selectedInfo;
    private TextView logView;
    private Spinner archiveSpinner;
    private Button prepareButton;
    private Button scanButton;
    private Button transferButton;
    private CheckBox experimentalAck;

    private File preparedFramesDir;
    private File preparedArchive;
    private boolean rootAvailable;
    private boolean busy;

    private static final class Stage {
        final String file;
        final int start;
        final int length;
        Stage(String file, int start, int length) {
            this.file = file;
            this.start = start;
            this.length = length;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildUi();
        requestStorageAccessIfNeeded();
        checkRootAsync();
        refreshArchives();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshArchives();
    }

    @Override protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Hubble 7570 · Root OTG");
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Samsung Galaxy J5 Prime · Exynos 7570 · EUB 04e8:1234");
        subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(4), 0, dp(12));
        root.addView(subtitle);

        rootStatus = new TextView(this);
        rootStatus.setText("Root: проверка…");
        rootStatus.setTextSize(15);
        root.addView(rootStatus);

        Button rootCheck = button("Проверить root");
        root.addView(rootCheck);
        rootCheck.setOnClickListener(v -> checkRootAsync());

        TextView folderLabel = new TextView(this);
        folderLabel.setText("BL-архивы из /sdcard/hubble");
        folderLabel.setTextSize(16);
        folderLabel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        folderLabel.setPadding(0, dp(14), 0, dp(5));
        root.addView(folderLabel);

        archiveSpinner = new Spinner(this);
        root.addView(archiveSpinner);

        Button refresh = button("Обновить список файлов");
        root.addView(refresh);
        refresh.setOnClickListener(v -> refreshArchives());

        selectedInfo = new TextView(this);
        selectedInfo.setText("Выбери BL_*.tar.md5 или BL_*.tar из /sdcard/hubble.");
        selectedInfo.setTextSize(13);
        selectedInfo.setPadding(0, dp(8), 0, dp(8));
        root.addView(selectedInfo);

        prepareButton = button("1. Проверить и подготовить S-Boot");
        root.addView(prepareButton);
        prepareButton.setOnClickListener(v -> prepareSelectedArchive());

        scanButton = button("Проверить OTG / Exynos EUB");
        root.addView(scanButton);
        scanButton.setOnClickListener(v -> scanUsb());

        TextView warning = new TextView(this);
        warning.setText("ВАЖНО: профиль SM-G570F экспериментальный. FWBL1 и BL31 имеют границы из заголовков образа; BL2 и U-Boot — эвристические границы. Успешное восстановление на Exynos 7570 пока не подтверждено. Несовпадающий SHA-256 блокируется.");
        warning.setTextSize(13);
        warning.setPadding(dp(10), dp(10), dp(10), dp(10));
        root.addView(warning);

        experimentalAck = new CheckBox(this);
        experimentalAck.setText("Я понимаю, что передача экспериментальная и может не восстановить телефон");
        root.addView(experimentalAck);

        transferButton = button("2. Передать стадии в EUB");
        transferButton.setEnabled(false);
        root.addView(transferButton);
        transferButton.setOnClickListener(v -> confirmAndTransfer());

        TextView logTitle = new TextView(this);
        logTitle.setText("Журнал");
        logTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logTitle.setTextSize(16);
        logTitle.setPadding(0, dp(18), 0, dp(6));
        root.addView(logTitle);

        logView = new TextView(this);
        logView.setTextSize(12);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.addView(logView);

        setContentView(scroll);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(5);
        lp.bottomMargin = dp(3);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void requestStorageAccessIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23) {
            List<String> missing = new ArrayList<>();
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                missing.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                missing.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), 41);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 41) refreshArchives();
    }

    private void refreshArchives() {
        File dir = new File(ARCHIVE_DIR);
        if (!dir.exists()) dir.mkdirs();
        archives.clear();
        File[] files = dir.listFiles((d, name) -> {
            String n = name.toLowerCase(Locale.ROOT);
            return n.endsWith(".tar.md5") || n.endsWith(".tar");
        });
        if (files != null) {
            Arrays.sort(files, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
            archives.addAll(Arrays.asList(files));
        }
        List<String> labels = new ArrayList<>();
        for (File f : archives) labels.add(f.getName() + "  ·  " + formatBytes(f.length()));
        if (labels.isEmpty()) labels.add("В /sdcard/hubble пока нет BL_*.tar.md5 / .tar");
        archiveSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        selectedInfo.setText("Каталог: " + ARCHIVE_DIR + "\nНайдено архивов: " + archives.size());
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.ROOT, "%.1f KiB", bytes / 1024.0);
        return String.format(Locale.ROOT, "%.2f MiB", bytes / (1024.0 * 1024.0));
    }

    private File selectedArchive() {
        int pos = archiveSpinner.getSelectedItemPosition();
        return pos >= 0 && pos < archives.size() ? archives.get(pos) : null;
    }

    private void checkRootAsync() {
        setBusy(true);
        worker.execute(() -> {
            String output;
            boolean ok = false;
            try {
                Process p = new ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start();
                output = readAll(p);
                int code = p.waitFor();
                ok = code == 0 && output.contains("uid=0");
                final String result = output.trim();
                final boolean root = ok;
                mainHandler.post(() -> {
                    rootAvailable = root;
                    rootStatus.setText(root ? "Root: доступен · " + result : "Root: не получен · " + result);
                    transferButton.setEnabled(root && preparedFramesDir != null && !busy);
                    appendLog(root ? "[root] SU OK: " + result : "[root] SU FAILED: " + result);
                    setBusy(false);
                });
            } catch (Exception e) {
                final String message = e.toString();
                mainHandler.post(() -> {
                    rootAvailable = false;
                    rootStatus.setText("Root: ошибка · " + message);
                    transferButton.setEnabled(false);
                    appendLog("[root] " + message);
                    setBusy(false);
                });
            }
        });
    }

    private void scanUsb() {
        if (!rootAvailable) {
            Toast.makeText(this, "Сначала предоставь приложению root-доступ", Toast.LENGTH_LONG).show();
            return;
        }
        setBusy(true);
        worker.execute(() -> {
            try {
                File bin = installRootBinary();
                Process p = new ProcessBuilder("su", "-c", "exec " + ROOT_BINARY_DEST + " --scan")
                        .redirectErrorStream(true).start();
                String output = streamProcess(p);
                int code = p.waitFor();
                String result = output + "\n[exit=" + code + "]";
                mainHandler.post(() -> { appendLog(result); setBusy(false); });
            } catch (Exception e) {
                String msg = e.toString();
                mainHandler.post(() -> { appendLog("[OTG] ERROR: " + msg); setBusy(false); });
            }
        });
    }

    private void prepareSelectedArchive() {
        File archive = selectedArchive();
        if (archive == null || !archive.isFile()) {
            Toast.makeText(this, "Сначала положи BL-архив в /sdcard/hubble", Toast.LENGTH_LONG).show();
            return;
        }
        setBusy(true);
        transferButton.setEnabled(false);
        appendLog("[prepare] Читаю " + archive.getName());
        worker.execute(() -> {
            try {
                byte[] compressed = FirmwareTools.extractTarEntry(archive, "sboot.bin.lz4");
                byte[] sboot = FirmwareTools.decompressLz4Frame(compressed);
                String sha = FirmwareTools.sha256(sboot);
                if (!EXPECTED_SBOOT_SHA256.equals(sha)) {
                    throw new IOException("S-Boot SHA-256 mismatch: " + sha + "\nОжидался только профиль SM-G570F: " + EXPECTED_SBOOT_SHA256);
                }
                if (sboot.length != 0x187110) throw new IOException("Unexpected S-Boot size: 0x" + Integer.toHexString(sboot.length));

                File frames = new File(getCacheDir(), "hubble-frames");
                if (frames.exists()) deleteRecursive(frames);
                if (!frames.mkdirs()) throw new IOException("Cannot create frame directory");

                List<String> summary = new ArrayList<>();
                for (Stage st : STAGES) {
                    if (st.start < 0 || st.length <= 0 || st.start + st.length > sboot.length)
                        throw new IOException("Invalid split range for " + st.file);
                    byte[] payload = Arrays.copyOfRange(sboot, st.start, st.start + st.length);
                    byte[] frame = FirmwareTools.makeDnwFrame(payload);
                    File out = new File(frames, st.file);
                    try (FileOutputStream fos = new FileOutputStream(out)) { fos.write(frame); fos.getFD().sync(); }
                    summary.add(String.format(Locale.ROOT, "%s: 0x%X + 0x%X → frame 0x%X", st.file, st.start, st.length, frame.length));
                }
                File boot = new File(frames, "sboot.sha256");
                try (FileOutputStream fos = new FileOutputStream(boot)) { fos.write((sha + "\n").getBytes(StandardCharsets.US_ASCII)); }

                final File resultFrames = frames;
                final File resultArchive = archive;
                final String report = "S-Boot SHA-256 OK: " + sha + "\nS-Boot size: 0x" + Integer.toHexString(sboot.length) + " (" + sboot.length + " bytes)\n" + String.join("\n", summary) + "\n\nХвост S-Boot от 0xFE000 до 0x187110 не передаётся: его роль в EUB-последовательности не установлена.";
                mainHandler.post(() -> {
                    preparedFramesDir = resultFrames;
                    preparedArchive = resultArchive;
                    selectedInfo.setText("Подготовлено: " + resultArchive.getName() + "\n" + report);
                    appendLog("[prepare] OK\n" + report);
                    transferButton.setEnabled(rootAvailable && !busy);
                    setBusy(false);
                });
            } catch (Exception e) {
                String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                mainHandler.post(() -> {
                    preparedFramesDir = null;
                    preparedArchive = null;
                    selectedInfo.setText("Подготовка остановлена: " + msg);
                    appendLog("[prepare] FAILED: " + msg);
                    transferButton.setEnabled(false);
                    setBusy(false);
                });
            }
        });
    }

    private void confirmAndTransfer() {
        if (!rootAvailable) {
            Toast.makeText(this, "Нет root-доступа", Toast.LENGTH_LONG).show();
            return;
        }
        if (preparedFramesDir == null || preparedArchive == null || !preparedFramesDir.isDirectory()) {
            Toast.makeText(this, "Сначала проверь и подготовь архив", Toast.LENGTH_LONG).show();
            return;
        }
        if (!experimentalAck.isChecked()) {
            Toast.makeText(this, "Подтверди предупреждение об экспериментальном профиле", Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Последнее подтверждение")
                .setMessage("Будут отправлены четыре DNW-кадра для SM-G570F. U-Boot будет отправлен одним USBFS Bulk OUT запросом. После BL2 приложение дождётся переподключения на том же OTG-порту.\n\nГраницы BL2/U-Boot не подтверждены успешным восстановлением. Не отключай OTG и держи Power на J5 Prime. Продолжить?")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Начать передачу", (d, w) -> startTransfer())
                .show();
    }

    private void startTransfer() {
        setBusy(true);
        transferButton.setEnabled(false);
        scanButton.setEnabled(false);
        appendLog("[transfer] Запуск root USBFS transport. Держи Power на J5 Prime.");
        worker.execute(() -> {
            try {
                installRootBinary();
                String command = "exec " + ROOT_BINARY_DEST + " --run " + shellQuote(preparedFramesDir.getAbsolutePath());
                Process p = new ProcessBuilder("su", "-c", command).redirectErrorStream(true).start();
                String output = streamProcess(p);
                int code = p.waitFor();
                final String result = output + "\n[transfer exit=" + code + "]";
                writeExternalLog(result);
                mainHandler.post(() -> {
                    appendLog(result);
                    if (code == 0) {
                        selectedInfo.setText("USBFS завершил передачу четырёх кадров. Это ещё не подтверждает запуск U-Boot или переход в Download Mode.");
                    } else {
                        selectedInfo.setText("Передача остановлена с ошибкой. Не запускай повторно автоматически: сначала проверь журнал и состояние EUB.");
                    }
                    setBusy(false);
                    scanButton.setEnabled(true);
                    transferButton.setEnabled(false);
                });
            } catch (Exception e) {
                String msg = e.toString();
                writeExternalLog(msg);
                mainHandler.post(() -> {
                    appendLog("[transfer] ERROR: " + msg);
                    setBusy(false);
                    scanButton.setEnabled(true);
                    transferButton.setEnabled(rootAvailable && preparedFramesDir != null);
                });
            }
        });
    }

    private File installRootBinary() throws IOException, InterruptedException {
        File local = new File(getFilesDir(), "hubbleusb-arm64");
        try (java.io.InputStream in = getAssets().open("hubbleusb-arm64"); FileOutputStream out = new FileOutputStream(local)) {
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            out.getFD().sync();
        }
        String cmd = "cp " + shellQuote(local.getAbsolutePath()) + " " + ROOT_BINARY_DEST + " && chmod 755 " + ROOT_BINARY_DEST;
        Process p = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
        String output = readAll(p);
        int code = p.waitFor();
        if (code != 0) throw new IOException("Cannot install root transport binary: " + output);
        return local;
    }

    private static String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    private String streamProcess(Process p) throws IOException {
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line).append('\n');
                String copy = line;
                mainHandler.post(() -> appendLog(copy));
            }
        }
        return result.toString();
    }

    private String readAll(Process p) throws IOException {
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line).append('\n');
        }
        return result.toString();
    }

    private void writeExternalLog(String message) {
        try {
            File dir = new File(ARCHIVE_DIR, "hubble-logs");
            if (!dir.exists()) dir.mkdirs();
            File out = new File(dir, "hubble-android-" + System.currentTimeMillis() + ".log");
            try (FileOutputStream fos = new FileOutputStream(out)) {
                fos.write(message.getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) { }
    }

    private void appendLog(String line) {
        if (logView == null) return;
        String current = logView.getText().toString();
        if (current.length() > 25_000) current = current.substring(current.length() - 15_000);
        logView.setText(current + (current.isEmpty() ? "" : "\n") + line);
    }

    private void setBusy(boolean value) {
        busy = value;
        if (prepareButton != null) prepareButton.setEnabled(!value && selectedArchive() != null);
        if (scanButton != null) scanButton.setEnabled(!value);
        if (transferButton != null) transferButton.setEnabled(!value && rootAvailable && preparedFramesDir != null);
    }

    private static void deleteRecursive(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursive(child);
        }
        file.delete();
    }
}
