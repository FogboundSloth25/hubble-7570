package com.validity.hubble7570;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Locale;

final class FirmwareTools {
    private FirmwareTools() {}

    static byte[] extractTarEntry(File archive, String wanted) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(archive, "r")) {
            byte[] header = new byte[512];
            while (raf.getFilePointer() + 512 <= raf.length()) {
                raf.readFully(header);
                boolean zero = true;
                for (byte b : header) if (b != 0) { zero = false; break; }
                if (zero) break;
                String name = cString(header, 0, 100);
                String prefix = cString(header, 345, 155);
                if (!prefix.isEmpty()) name = prefix + "/" + name;
                long size = parseTarOctal(header, 124, 12);
                long dataStart = raf.getFilePointer();
                if (name.equals(wanted) || name.endsWith("/" + wanted)) {
                    if (size > 32L * 1024 * 1024) throw new IOException("Archive entry too large: " + size);
                    byte[] out = new byte[(int)size];
                    raf.readFully(out);
                    return out;
                }
                long next = dataStart + size + ((512 - (size % 512)) % 512);
                if (next < dataStart || next > raf.length()) throw new IOException("Invalid tar entry size/offset for " + name);
                raf.seek(next);
            }
        }
        throw new IOException("Archive does not contain " + wanted);
    }

    private static String cString(byte[] b, int off, int max) {
        int end = off;
        while (end < off + max && b[end] != 0) end++;
        return new String(b, off, end - off, StandardCharsets.US_ASCII).trim();
    }

    private static long parseTarOctal(byte[] b, int off, int len) throws IOException {
        if ((b[off] & 0x80) != 0) throw new IOException("Base-256 tar sizes are not supported");
        String s = new String(b, off, len, StandardCharsets.US_ASCII).replace("\0", "").trim();
        if (s.isEmpty()) return 0;
        try { return Long.parseLong(s, 8); }
        catch (NumberFormatException e) { throw new IOException("Invalid tar size field: " + s, e); }
    }

    static byte[] decompressLz4Frame(byte[] src) throws IOException {
        final int magic = 0x184D2204;
        if (src.length < 7 || le32(src, 0) != magic) throw new IOException("Not an LZ4 frame (bad magic)");
        int p = 4;
        int flg = src[p++] & 0xff;
        int bd = src[p++] & 0xff;
        if ((flg >>> 6) != 1) throw new IOException("Unsupported LZ4 frame version");
        if ((flg & 0x02) != 0) throw new IOException("Reserved LZ4 FLG bit is set");
        if ((bd & 0x8f) != 0) throw new IOException("Reserved LZ4 BD bits are set");

        ByteArrayOutputStream descriptor = new ByteArrayOutputStream();
        descriptor.write(flg); descriptor.write(bd);
        long contentSize = -1;
        if ((flg & 0x08) != 0) {
            if (p + 8 > src.length) throw new IOException("Truncated LZ4 content-size field");
            contentSize = le64(src, p);
            descriptor.write(src, p, 8);
            p += 8;
        }
        if ((flg & 0x01) != 0) {
            if (p + 4 > src.length) throw new IOException("Truncated LZ4 dictionary ID");
            throw new IOException("LZ4 dictionary frames are unsupported");
        }
        if (p >= src.length) throw new IOException("Truncated LZ4 header checksum");
        int hc = src[p++] & 0xff;
        byte[] desc = descriptor.toByteArray();
        if (((xxh32(desc, 0, desc.length, 0) >>> 8) & 0xff) != hc)
            throw new IOException("LZ4 header checksum mismatch");

        int maxBlockCode = (bd >>> 4) & 0x07;
        int maxBlockSize;
        switch (maxBlockCode) {
            case 4: maxBlockSize = 64 * 1024; break;
            case 5: maxBlockSize = 256 * 1024; break;
            case 6: maxBlockSize = 1024 * 1024; break;
            case 7: maxBlockSize = 4 * 1024 * 1024; break;
            default: throw new IOException("Invalid LZ4 max block size code: " + maxBlockCode);
        }

        ByteArrayOutputStream output = new ByteArrayOutputStream(contentSize > 0 && contentSize < Integer.MAX_VALUE ? (int)contentSize : 1024 * 1024);
        boolean ended = false;
        while (p + 4 <= src.length) {
            int blockField = le32(src, p); p += 4;
            if (blockField == 0) { ended = true; break; }
            boolean uncompressed = (blockField & 0x80000000) != 0;
            int blockLength = blockField & 0x7fffffff;
            if (blockLength <= 0 || blockLength > maxBlockSize || p + blockLength > src.length)
                throw new IOException("Invalid LZ4 block length: " + blockLength);
            if ((flg & 0x10) != 0) {
                // Block checksum follows the compressed bytes; verify below.
            }
            byte[] block = Arrays.copyOfRange(src, p, p + blockLength);
            p += blockLength;
            if (uncompressed) output.write(block);
            else output.write(decodeLz4Block(block, maxBlockSize));
            if ((flg & 0x10) != 0) {
                if (p + 4 > src.length) throw new IOException("Missing LZ4 block checksum");
                int expected = le32(src, p); p += 4;
                if (xxh32(block, 0, block.length, 0) != expected) throw new IOException("LZ4 block checksum mismatch");
            }
        }
        if (!ended) throw new IOException("LZ4 end-of-frame marker missing");
        byte[] result = output.toByteArray();
        if ((flg & 0x04) != 0) {
            if (p + 4 > src.length) throw new IOException("Missing LZ4 content checksum");
            int expected = le32(src, p); p += 4;
            if (xxh32(result, 0, result.length, 0) != expected) throw new IOException("LZ4 content checksum mismatch");
        }
        if (contentSize >= 0 && contentSize != result.length)
            throw new IOException("LZ4 content size mismatch: " + contentSize + " vs " + result.length);
        if (p != src.length) throw new IOException("Unexpected trailing bytes after LZ4 frame: " + (src.length - p));
        return result;
    }

    private static byte[] decodeLz4Block(byte[] in, int maxOutput) throws IOException {
        byte[] out = new byte[maxOutput];
        int ip = 0, op = 0;
        while (ip < in.length) {
            int token = in[ip++] & 0xff;
            int literalLength = token >>> 4;
            if (literalLength == 15) {
                int x;
                do {
                    if (ip >= in.length) throw new IOException("Truncated LZ4 literal length");
                    x = in[ip++] & 0xff;
                    literalLength += x;
                } while (x == 255);
            }
            if (literalLength < 0 || ip + literalLength > in.length || op + literalLength > out.length)
                throw new IOException("LZ4 literal overruns block");
            System.arraycopy(in, ip, out, op, literalLength);
            ip += literalLength;
            op += literalLength;
            if (ip == in.length) break;
            if (ip + 2 > in.length) throw new IOException("Truncated LZ4 match offset");
            int distance = (in[ip] & 0xff) | ((in[ip + 1] & 0xff) << 8);
            ip += 2;
            if (distance <= 0 || distance > op) throw new IOException("Invalid LZ4 match distance: " + distance);
            int matchLength = token & 0x0f;
            if (matchLength == 15) {
                int x;
                do {
                    if (ip >= in.length) throw new IOException("Truncated LZ4 match length");
                    x = in[ip++] & 0xff;
                    matchLength += x;
                } while (x == 255);
            }
            matchLength += 4;
            if (op + matchLength > out.length) throw new IOException("LZ4 match overruns output block");
            for (int i = 0; i < matchLength; i++) out[op + i] = out[op + i - distance];
            op += matchLength;
        }
        return Arrays.copyOf(out, op);
    }

    private static int le32(byte[] b, int p) {
        return (b[p] & 0xff) | ((b[p+1] & 0xff) << 8) | ((b[p+2] & 0xff) << 16) | ((b[p+3] & 0xff) << 24);
    }

    private static long le64(byte[] b, int p) {
        long v = 0;
        for (int i = 7; i >= 0; i--) v = (v << 8) | (b[p+i] & 0xffL);
        return v;
    }

    private static int xxh32(byte[] b, int off, int len, int seed) {
        final int P1 = 0x9E3779B1, P2 = 0x85EBCA77, P3 = 0xC2B2AE3D, P4 = 0x27D4EB2F, P5 = 0x165667B1;
        int p = off, end = off + len, h;
        if (len >= 16) {
            int v1 = seed + P1 + P2, v2 = seed + P2, v3 = seed, v4 = seed - P1;
            int limit = end - 16;
            do {
                v1 = xxhRound(v1, le32(b, p)); p += 4;
                v2 = xxhRound(v2, le32(b, p)); p += 4;
                v3 = xxhRound(v3, le32(b, p)); p += 4;
                v4 = xxhRound(v4, le32(b, p)); p += 4;
            } while (p <= limit);
            h = Integer.rotateLeft(v1, 1) + Integer.rotateLeft(v2, 7) + Integer.rotateLeft(v3, 12) + Integer.rotateLeft(v4, 18);
        } else h = seed + P5;
        h += len;
        while (p + 4 <= end) { h += le32(b, p) * P3; h = Integer.rotateLeft(h, 17) * P4; p += 4; }
        while (p < end) { h += (b[p++] & 0xff) * P5; h = Integer.rotateLeft(h, 11) * P1; }
        h ^= h >>> 15; h *= P2; h ^= h >>> 13; h *= P3; h ^= h >>> 16;
        return h;
    }

    private static int xxhRound(int acc, int input) {
        acc += input * 0x85EBCA77;
        acc = Integer.rotateLeft(acc, 13);
        return acc * 0x9E3779B1;
    }

    static String sha256(byte[] bytes) throws Exception {
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(bytes);
        StringBuilder s = new StringBuilder();
        for (byte b : hash) s.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return s.toString();
    }

        static byte[] makeDnwFrame(byte[] payload) throws IOException {
            int size = payload.length + 10;
            byte[] frame = new byte[size];
            frame[0] = 0x1b;
            frame[1] = 'D'; frame[2] = 'N'; frame[3] = 'W';
            frame[4] = (byte)(size & 0xff);
            frame[5] = (byte)((size >>> 8) & 0xff);
            frame[6] = (byte)((size >>> 16) & 0xff);
            frame[7] = (byte)((size >>> 24) & 0xff);
            System.arraycopy(payload, 0, frame, 8, payload.length);
            frame[size - 2] = (byte)0xff;
            frame[size - 1] = (byte)0xff;
            return frame;
        }
}
