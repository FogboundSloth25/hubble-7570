#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v java >/dev/null || { echo "JDK 17+ is required" >&2; exit 1; }
command -v go >/dev/null || { echo "Go 1.23+ is required to build the Android USBFS helper" >&2; exit 1; }

: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
if [[ -z "$ANDROID_HOME" ]]; then
  echo "Set ANDROID_HOME to an Android SDK containing platform 35 and build-tools." >&2
  exit 1
fi

mkdir -p app/src/main/assets
GOOS=android GOARCH=arm64 CGO_ENABLED=0 go build \
  -trimpath -ldflags='-s -w' \
  -o app/src/main/assets/hubbleusb-arm64 usbhost/main.go
./gradlew assembleDebug
printf '\nAPK: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
