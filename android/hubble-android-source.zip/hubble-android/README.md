# Hubble 7570 Root OTG (experimental)

Android ARM64 host application for the Samsung Galaxy J5 Prime SM-G570F / Exynos 7570 EUB recovery experiment.

## What it does

- Lists `.tar.md5` and `.tar` BL archives from `/sdcard/hubble`.
- Extracts `sboot.bin.lz4` directly from the Samsung TAR archive.
- Decompresses the LZ4 frame and verifies the exact S-Boot SHA-256 used by the experimental SM-G570F profile.
- Builds the four DNW frames used by the current Hubble profile.
- Requests `su` and launches the included Android ARM64 USBFS transport as root.
- Talks to `04e8:1234` through `/dev/bus/usb` using Linux `USBDEVFS_CLAIMINTERFACE` / `USBDEVFS_BULK` ioctls. It does not depend on Android's per-attach `UsbManager` permission dialog.
- Sends U-Boot as one USBFS bulk ioctl, then checks the same physical sysfs USB port for a re-enumerated EUB device after BL2.

This is a native Android port of Hubble's DNW framing and stage sequence, not the original Python interpreter embedded into Android.

## Important limitations

**The SM-G570F split profile is experimental.** The exact image identity is checked, but that does not prove that all split boundaries are correct:

| Stage | Offset | Length | Evidence |
|---|---:|---:|---|
| FWBL1 | `0x00000` | `0x02000` | BL1 size word in image |
| BL31 / second stage | `0x02000` | `0x1E000` | size word and `daeh` marker |
| BL2 | `0x20000` | `0x0D000` | detector-derived boundary |
| U-Boot | `0x2D000` | `0xD1000` | Exynos7 detector heuristic |

The bytes from `0xFE000` to `0x187110` are deliberately not sent. They contain further signature candidates and TEEgris-related strings; their role in this EUB boot sequence has not been established.

The app blocks any S-Boot whose decompressed SHA-256 does not exactly match:

`505b9b9e8192b9fa4ee4bb2229e7934327444a47c408eaa6b300facb1c629841`

No successful recovery / Download Mode transition on this device has been demonstrated. A successful USBFS write only means the host kernel accepted the transfer; it does not prove that Exynos boot code accepted or executed the image.

## Use

1. On the rooted ARM64 Android host phone, create `/sdcard/hubble/`.
2. Put the Samsung BL archive there, for example `BL_G570F...tar.md5`.
3. Connect the J5 Prime to the Android host using USB OTG.
4. Keep the J5 Prime Power button held while in EUB.
5. Install the debug APK built from this project.
6. Grant storage permission and approve the `su` request.
7. Use **Проверить OTG / Exynos EUB**. It should find `04e8:1234`.
8. Select the BL archive and press **Проверить и подготовить S-Boot**. The app must show the expected SHA-256.
9. Read the experimental-profile warning, tick the acknowledgement, and only then start the transfer.
10. Do not unplug OTG or release Power during the transfer. Do not automatically retry after any failure; inspect the log and current EUB state first.

Logs are also written under `/sdcard/hubble/hubble-logs/` when external-storage access is available.

## Build

Requirements:

- Android Studio or Android SDK Platform 35
- Android Gradle Plugin `8.9.2`
- Gradle `8.11.1` or compatible
- JDK 17+
- Go toolchain (only needed if rebuilding the USBFS helper)

Open this directory in Android Studio and build **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Or from a machine with Android SDK configured:

```bash
ANDROID_HOME="$HOME/Android/Sdk" ./build.sh
```

The included `gradlew` bootstrap downloads Gradle 8.11.1 from the official Gradle distribution host on first use. `build.sh` first cross-compiles `usbhost/main.go` for Android ARM64 and places it in the app assets before running Gradle.

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

The ARM64 USBFS helper is generated from `usbhost/main.go` by `build.sh`; the prebuilt binary is intentionally not stored in source control.

## Implementation notes

- The root helper is compiled for `GOOS=android GOARCH=arm64` and copied by the app to `/data/local/tmp/hubble7570-usb` before launch.
- It opens the sysfs-discovered USB node under `/dev/bus/usb/BBB/DDD`, claims interface 0, and sends endpoint `0x02` with one synchronous `USBDEVFS_BULK` ioctl per DNW frame.
- The frame format is the same Hubble framing: `1b 44 4e 57`, little-endian total frame size, payload, then `ff ff`.
- There is deliberately no automatic retransmission of a partially sent DNW frame.
- This project targets `arm64-v8a` only.

## Licensing

The original Hubble project identifies itself as GPL-2.0. The Hubble-derived DNW framing / stage workflow in this project is provided under GPL-2.0. The Android UI and USBFS helper source are included in this archive.
