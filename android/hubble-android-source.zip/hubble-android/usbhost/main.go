// Hubble 7570 Android USBFS transport.
// Built as a pure-Go Android arm64 executable and executed by su.
// It uses Linux usbfs directly so Android's per-attach UsbManager permission
// dialog is not needed. The DNW framing/layout mirrors the experimental Hubble
// profile; the U-Boot split remains unverified on physical Exynos 7570 hardware.
package main

import (
    "errors"
    "fmt"
    "os"
    "path/filepath"
    "runtime"
    "sort"
    "strconv"
    "strings"
    "syscall"
    "time"
    "unsafe"
)

const (
    vid = "04e8"
    pid = "1234"
    expectedProduct = "Exynos7570"

    usbDevfsBulk         = 0xC0185502 // _IOWR('U', 2, struct usbdevfs_bulktransfer)
    usbDevfsClaimIface   = 0x8004550F // _IOR('U', 15, unsigned int)
    usbDevfsReleaseIface = 0x80045510 // _IOR('U', 16, unsigned int)
    outEndpoint          = 0x02
    ifaceNumber          = 0
    transferTimeoutMs    = 50000
)

type bulkTransfer struct {
    Endpoint uint32
    Length   uint32
    Timeout  uint32
    Padding  uint32
    Data     uintptr
}

type usbDevice struct {
    SysfsPath string
    Name      string
    Bus       int
    Dev       int
    Product   string
}

func logf(format string, args ...any) {
    fmt.Printf("[%s] "+format+"\n", append([]any{time.Now().Format("15:04:05.000")}, args...)...)
}

func readTrim(path string) string {
    b, err := os.ReadFile(path)
    if err != nil { return "" }
    return strings.TrimSpace(string(b))
}

func discover() []usbDevice {
    entries, _ := filepath.Glob("/sys/bus/usb/devices/*")
    found := make([]usbDevice, 0)
    for _, p := range entries {
        if strings.Contains(filepath.Base(p), ":") { continue }
        if strings.ToLower(readTrim(filepath.Join(p, "idVendor"))) != vid ||
           strings.ToLower(readTrim(filepath.Join(p, "idProduct"))) != pid { continue }
        product := readTrim(filepath.Join(p, "product"))
        if product != expectedProduct { continue }
        bus, e1 := strconv.Atoi(readTrim(filepath.Join(p, "busnum")))
        dev, e2 := strconv.Atoi(readTrim(filepath.Join(p, "devnum")))
        if e1 != nil || e2 != nil || bus <= 0 || dev <= 0 { continue }
        found = append(found, usbDevice{
            SysfsPath:p, Name:filepath.Base(p), Bus:bus, Dev:dev,
            Product:product,
        })
    }
    sort.Slice(found, func(i,j int) bool { return found[i].Name < found[j].Name })
    return found
}

func usbNode(d usbDevice) string {
    return fmt.Sprintf("/dev/bus/usb/%03d/%03d", d.Bus, d.Dev)
}

func findInitial(timeout time.Duration) (usbDevice, error) {
    deadline := time.Now().Add(timeout)
    for time.Now().Before(deadline) {
        ds := discover()
        if len(ds) > 0 { return ds[0], nil }
        time.Sleep(25*time.Millisecond)
    }
    return usbDevice{}, fmt.Errorf("Exynos7570 EUB 04e8:1234 not found; check OTG cable, device product string, and keep J5 Prime Power held")
}

func openAndClaim(d usbDevice) (*os.File, error) {
    f, err := os.OpenFile(usbNode(d), os.O_RDWR, 0)
    if err != nil { return nil, fmt.Errorf("open %s: %w", usbNode(d), err) }
    iface := uint32(ifaceNumber)
    _, _, errno := syscall.Syscall(syscall.SYS_IOCTL, f.Fd(), usbDevfsClaimIface, uintptr(unsafe.Pointer(&iface)))
    runtime.KeepAlive(&iface)
    if errno != 0 {
        f.Close()
        return nil, fmt.Errorf("USBDEVFS_CLAIMINTERFACE interface 0: %w", errno)
    }
    return f, nil
}


func releaseAndClose(f *os.File) {
    if f == nil { return }
    iface := uint32(ifaceNumber)
    _, _, _ = syscall.Syscall(syscall.SYS_IOCTL, f.Fd(), usbDevfsReleaseIface, uintptr(unsafe.Pointer(&iface)))
    f.Close()
}

func bulkWrite(f *os.File, data []byte) (int, error) {
	if len(data) == 0 {
		return 0, errors.New("refusing empty DNW frame")
	}

	// USBDEVFS_BULK in the kernel allocates a kmalloc() buffer sized to
	// each ioctl request. A whole 120 KiB DNW frame can fail with ENOMEM
	// on a fragmented Android kernel even when MemAvailable is large.
	// Keep each request to one 4 KiB page and preserve the original byte
	// stream. 4 KiB is divisible by common 512/64-byte bulk max-packet sizes.
	const chunkSize = 4096
	total := 0
	for total < len(data) {
		end := total + chunkSize
		if end > len(data) {
			end = len(data)
		}
		chunk := data[total:end]
		x := bulkTransfer{
			Endpoint: outEndpoint,
			Length:   uint32(len(chunk)),
			Timeout:  transferTimeoutMs,
			Data:     uintptr(unsafe.Pointer(&chunk[0])),
		}
		r1, _, errno := syscall.Syscall(syscall.SYS_IOCTL, f.Fd(), usbDevfsBulk, uintptr(unsafe.Pointer(&x)))
		// The ioctl is synchronous; retain pointer-backed arguments until return.
		runtime.KeepAlive(chunk)
		runtime.KeepAlive(data)
		runtime.KeepAlive(&x)
		if errno != 0 {
			return total, fmt.Errorf("USBDEVFS_BULK chunk offset=0x%X length=%d: %w", total, len(chunk), errno)
		}
		written := int(r1)
		if written != len(chunk) {
			return total + written, fmt.Errorf("short USBFS chunk at offset=0x%X: %d/%d bytes", total, written, len(chunk))
		}
		total += written
		logf("OUT CHUNK OK offset=0x%X bytes=%d cumulative=%d/%d", total-len(chunk), written, total, len(data))
	}
	return total, nil
}

func sendStage(f *os.File, framesDir, filename string) error {
    path := filepath.Join(framesDir, filename)
    data, err := os.ReadFile(path)
    if err != nil { return fmt.Errorf("read %s: %w", filename, err) }
    if len(data) < 10 || string(data[:4]) != "\x1bDNW" {
        return fmt.Errorf("%s is not a complete DNW frame", filename)
    }
    declared := uint32(data[4]) | uint32(data[5])<<8 | uint32(data[6])<<16 | uint32(data[7])<<24
    if declared != uint32(len(data)) || data[len(data)-1] != 0xff || data[len(data)-2] != 0xff {
        return fmt.Errorf("%s DNW header/trailer mismatch: declared=%d actual=%d", filename, declared, len(data))
    }
    logf("OUT BEGIN stage=%s frame=%d bytes (0x%X) endpoint=0x%02X timeout=%dms", filename, len(data), len(data), outEndpoint, transferTimeoutMs)
    started := time.Now()
    n, err := bulkWrite(f, data) // one USBFS bulk request, including the entire U-Boot frame
    elapsed := time.Since(started)
    if err != nil {
        return fmt.Errorf("OUT FAILED stage=%s after=%s transferred_reported=%d: %w; frame NOT retried", filename, elapsed, n, err)
    }
    if n != len(data) {
        return fmt.Errorf("short USB transfer stage=%s: %d/%d bytes after %s; frame NOT retried", filename, n, len(data), elapsed)
    }
    logf("OUT OK stage=%s bytes=%d elapsed=%s", filename, n, elapsed)
    return nil
}

func waitForSamePort(old usbDevice, timeout time.Duration) (usbDevice, error) {
    logf("waiting for EUB re-enumeration on physical OTG port %s (bus=%d old-devnum=%d), timeout=%s", old.Name, old.Bus, old.Dev, timeout)
    deadline := time.Now().Add(timeout)
    sawGone := false
    for time.Now().Before(deadline) {
        var current *usbDevice
        for _, d := range discover() {
            if d.Name == old.Name && d.Bus == old.Bus {
                copy := d
                current = &copy
                break
            }
        }
        if current == nil {
            sawGone = true
        } else if sawGone || current.Dev != old.Dev {
            logf("EUB returned on same port: %s bus=%d devnum=%d product=%q", current.Name, current.Bus, current.Dev, current.Product)
            return *current, nil
        }
        time.Sleep(10*time.Millisecond)
    }
    return usbDevice{}, fmt.Errorf("EUB did not return on sysfs port %s within %s", old.Name, timeout)
}

func run(framesDir string) error {
    logf("root USBFS transport starting; looking for Samsung Exynos7570 EUB 04e8:1234")
    d, err := findInitial(15*time.Second)
    if err != nil { return err }
    logf("found %s bus=%d devnum=%d product=%q node=%s", d.Name, d.Bus, d.Dev, d.Product, usbNode(d))
    f, err := openAndClaim(d)
    if err != nil { return err }

    stages := []string{"fwbl1.dnw", "bl31.dnw", "bl2.dnw", "u-boot.dnw"}
    for i, stage := range stages {
        if err := sendStage(f, framesDir, stage); err != nil {
            releaseAndClose(f)
            return err
        }
        if stage == "bl2.dnw" {
            releaseAndClose(f)
            f = nil
            next, err := waitForSamePort(d, 10*time.Second)
            if err != nil { return err }
            d = next
            f, err = openAndClaim(d)
            if err != nil { return fmt.Errorf("re-enumerated EUB found but interface claim failed: %w", err) }
            logf("interface 0 reclaimed; ready for U-Boot")
        } else if i == len(stages)-1 {
            // Nothing follows U-Boot in this experimental profile.
        }
    }
    releaseAndClose(f)
    logf("all four DNW frames accepted by USBFS; this does NOT prove bootloader execution or Download Mode")
    return nil
}

func main() {
    if len(os.Args) < 2 {
        fmt.Println("usage: hubbleusb --scan | --run <frames-directory>")
        os.Exit(2)
    }
    switch os.Args[1] {
    case "--scan":
        d, err := findInitial(8*time.Second)
        if err != nil { logf("SCAN FAILED: %v", err); os.Exit(1) }
        logf("SCAN OK: %s bus=%d devnum=%d product=%q node=%s", d.Name, d.Bus, d.Dev, d.Product, usbNode(d))
    case "--run":
        if len(os.Args) != 3 { fmt.Println("usage: hubbleusb --run <frames-directory>"); os.Exit(2) }
        if err := run(os.Args[2]); err != nil { logf("FATAL: %v", err); os.Exit(1) }
    default:
        fmt.Println("unknown command")
        os.Exit(2)
    }
}
