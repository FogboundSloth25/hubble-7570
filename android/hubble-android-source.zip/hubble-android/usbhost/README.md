# Android USBFS helper

`main.go` is a pure-Go Android ARM64 executable. It must be launched via `su` because it opens `/dev/bus/usb/*/*` directly. It intentionally makes a single synchronous USBFS bulk request for each already-framed DNW image. The executable scans `/sys/bus/usb/devices` for VID:PID `04e8:1234` and requires the re-enumerated device after BL2 to remain on the same sysfs port path.

The code does not retry a failed or partial frame. The device's exact Exynos 7570 receive semantics and the heuristic U-Boot boundary remain unverified.
